CORALLO BEACH — DEMO V2
Nuova logica: verde = libero per tutto il periodo; giallo = parzialmente disponibile; rosso = mai disponibile nel periodo. Se si sceglie un giallo, il sistema cerca automaticamente una soluzione multi-ombrellone con il minor numero possibile di cambi.
